# create-evershop-app

This package includes the global command for [Create EverShop App](https://evershop.io/).<br> Please refer to its documentation:

- [Getting Started](https://evershop.io/docs/development/getting-started/introduction) – How to create a new app.
- [Development Guide](https://evershop.io/docs/development/) – How to develop an ecommerce web app with EverShop.
